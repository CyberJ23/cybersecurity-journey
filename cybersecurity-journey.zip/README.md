# Cybersecurity Learning Journey

This repo tracks my 12-month plan to become a top-tier cybersecurity professional.

## 🔥 Current Phase: Week 1 – Foundations

### ✅ Weekly Goals
- [x] Complete Google Cert Module 1
- [ ] Finish TryHackMe: Linux Fundamentals Pt. 1
- [ ] Write a basic Python script (calculator)
- [ ] Add 50 Anki flashcards
- [ ] Publish weekly summary to GitHub

## 📚 Repository Structure
- `/weekly-notes`: Polished, recruiter-ready summaries
- `/daily-logs`: Raw, detailed daily reflections
- `/labs`: Writeups from TryHackMe, CTFs, BlueTeamLabs
- `/scripts`: Python, Bash, PowerShell files
- `/journal-assets`: Flashcard terms, diagrams, or summaries

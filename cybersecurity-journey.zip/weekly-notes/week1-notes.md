# 🛡️ Week 1 – Cybersecurity Learning Journal

## 📅 Dates:
July 8–14, 2025

## 🎯 Weekly Goals:
- [x] Complete Google Cert Module 1
- [ ] Finish TryHackMe Linux Fundamentals Pt. 1
- [ ] Write Python script: calculator
- [ ] Add 50+ Anki flashcards
- [ ] Publish GitHub update

## 🧠 What I Learned

### 👨‍🏫 Google Cybersecurity Certificate – Module 1
**Key Topics:**
- CIA Triad
- Threat Actors
- Vulnerabilities vs. Explloits

**Takeaways:**
> Cybersecurity involves technical tools *and* people + process.

## 🔄 Reflections
- Learning the CIA Triad helps frame everything else.
